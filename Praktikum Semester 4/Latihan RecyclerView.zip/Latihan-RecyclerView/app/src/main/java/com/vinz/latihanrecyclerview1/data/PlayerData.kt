package com.vinz.latihanrecyclerview1.data

// Seperti variabel namun lebih powerful, fungsinya untuk menyimpan data yang kita butuhkan
data class PlayerData (
    val name: String,
    val description: String,
    val image: Int
)